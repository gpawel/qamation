package org.qamation.keyboard;


import org.openqa.selenium.interactions.Keyboard;

public class WebDriverKeyboard implements Keyboard {
    @Override
    public void sendKeys(CharSequence... charSequences) {

    }

    @Override
    public void pressKey(CharSequence charSequence) {

    }

    @Override
    public void releaseKey(CharSequence charSequence) {

    }
}
