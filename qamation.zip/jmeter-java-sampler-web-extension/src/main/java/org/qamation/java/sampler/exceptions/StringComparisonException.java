package org.qamation.java.sampler.exceptions;

public class StringComparisonException extends RuntimeException {

	public StringComparisonException (String message) {
		super(message);
	}

}
