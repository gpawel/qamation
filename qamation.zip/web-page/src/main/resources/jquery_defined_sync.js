var isJQueryDefined = (window.jQuery == undefined) ? false:true;
console.log("jquery_defined_sync; ",isJQueryDefined);
return isJQueryDefined;