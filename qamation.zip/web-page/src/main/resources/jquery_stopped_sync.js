var isJQueryActive = ($.active == 0) ? true:false;
console.log("jquery_stopped_sync; ",isJQueryActive);
return isJQueryActive;