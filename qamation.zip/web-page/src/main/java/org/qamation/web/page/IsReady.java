package org.qamation.web.page;

public interface IsReady {
	public boolean isReady();
}
